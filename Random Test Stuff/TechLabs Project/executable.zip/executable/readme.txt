rooms.json stores all data. By default, it contains a test room. You can delete it and replace it with rooms more suited to your company's purpose.

(I wanted to make it exportable as an exe just for fun, the python file should work fine by itself.)